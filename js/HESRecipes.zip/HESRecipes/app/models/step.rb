class Step < ActiveRecord::Base
  belongs_to :recipe
end
