class IngredientsController < ApplicationController
  # GET /ingredients/new
  def new
  end

  # POST /ingredients
  def create
  end

  # GET /ingredients/:id/edit
  def edit
  end

  # PUT /ingredients/:id
  def update
  end

  # DELETE /ingredients/:id
  def destroy
  end
end
