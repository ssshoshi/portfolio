class StepsController < ApplicationController
  # GET /steps/new
  def new
  end

  # POST /steps
  def create
  end

  # GET /steps/:id/edit
  def edit
  end

  # PUT /steps/:id
  def update
  end

  # DELETE /steps/:id
  def destroy
  end
end
