# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Recipes::Application.config.secret_token = '1e94d21aa226cccdd2d0668baf6720d21239098cb210a98e1d58888f74da68bf84a1a36aa3eb835e073be6a21bba83727ece13d790ee62b0da2ba2c35b2e4b15'
